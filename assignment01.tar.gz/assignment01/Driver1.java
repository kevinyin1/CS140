package assignment01;

public class Driver1 {
	
	public static void main(String[] args) {
		BankAccount acct = new BankAccount("Jane Smith", 100.0);
		System.out.println(acct);
	}
}
