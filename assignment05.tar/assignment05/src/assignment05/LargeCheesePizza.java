package assignment05;

public class LargeCheesePizza implements Pizza {

	@Override
	public int compareTo(Pizza o) {
		// TODO Auto-generated method stub
		return 1;
	}

	@Override
	public String getDescription() {
		return "Large cheese pizza";
	}

	@Override
	public double getCost() {
		//
		return 12.5;
	}
	
}
