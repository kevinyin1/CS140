package assignment05;

public class Parent {

	private String pName;
	
	public void setpName(String pName) {
		this.pName = pName;
	}
	
	public void print() {
		System.out.println(pName);
	}
}
