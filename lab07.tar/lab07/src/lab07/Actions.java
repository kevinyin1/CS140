package lab07;

public interface Actions {

	void speak();
	void eat();
	void move();
	void sleep();
	
}
	